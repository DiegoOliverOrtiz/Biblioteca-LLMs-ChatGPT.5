# bibliotecamonolitica

Aplicación monolítica MVC para gestión de biblioteca (ISO/IEC 25010, trazabilidad, pruebas y cobertura).

## Requisitos
- Java 17
- Maven 3.8+
- (Producción) MySQL con credenciales en variables de entorno:
  - `MYSQL_URL` (p.ej. `jdbc:mysql://localhost:3306/biblioteca?useSSL=false&serverTimezone=UTC`)
  - `MYSQL_USER`
  - `MYSQL_PASSWORD`

## Compilación y ejecución
```bash
mvn -q clean package
java -jar target/bibliotecamonolitica-1.0.0.jar
```

## Base de datos
Crea el esquema y datos de ejemplo:
```bash
mysql -u$MYSQL_USER -p -e "CREATE DATABASE IF NOT EXISTS biblioteca;"
mysql -u$MYSQL_USER -p biblioteca < src/main/resources/sql/schema.sql
mysql -u$MYSQL_USER -p biblioteca < src/main/resources/sql/seed.sql
```

## Pruebas y cobertura (JaCoCo ≥ 90%)
```bash
mvn -q test
# Informe cobertura: target/site/jacoco/index.html
mvn -q verify  # falla si la cobertura < 90%
```

## Generación de Javadoc
```bash
mvn -q javadoc:javadoc
# Salida oficial: target/site/apidocs/index.html
# En este repositorio también incluimos 'source/apidocs' autogenerado con un índice de clases.
```

## Estructura
- `src/main/java/es/uclm/esi/iso2/bibliotecamonolitica/...`
- `src/test/java/es/uclm/esi/iso2/bibliotecamonolitica/...`
- `src/main/resources/sql/schema.sql`, `seed.sql`
- `source/apidocs` (HTML ligero autogenerado desde fuentes)

## Licencia
Docente / académico.
