-- Esquema relacional (una clase ↔ una tabla)
CREATE TABLE IF NOT EXISTS users (
  email VARCHAR(255) PRIMARY KEY,
  name  VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS books (
  isbn   VARCHAR(20) PRIMARY KEY,
  title  VARCHAR(255) NOT NULL,
  author VARCHAR(255) NOT NULL
);

CREATE TABLE IF NOT EXISTS loans (
  id          VARCHAR(64) PRIMARY KEY,
  user_email  VARCHAR(255) NOT NULL,
  book_isbn   VARCHAR(20)  NOT NULL,
  start_date  DATE NOT NULL,
  due_date    DATE NOT NULL,
  closed      BOOLEAN NOT NULL DEFAULT FALSE,
  CONSTRAINT fk_loans_user FOREIGN KEY (user_email) REFERENCES users(email),
  CONSTRAINT fk_loans_book FOREIGN KEY (book_isbn) REFERENCES books(isbn)
);

CREATE TABLE IF NOT EXISTS fines (
  loan_id    VARCHAR(64) PRIMARY KEY,
  amount     DECIMAL(12,2) NOT NULL,
  applied_on DATE NOT NULL,
  CONSTRAINT fk_fines_loan FOREIGN KEY (loan_id) REFERENCES loans(id)
);