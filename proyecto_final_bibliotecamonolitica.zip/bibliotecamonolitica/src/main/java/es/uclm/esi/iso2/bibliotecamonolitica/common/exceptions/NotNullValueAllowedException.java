package es.uclm.esi.iso2.bibliotecamonolitica.common.exceptions;

/**
 * Excepción lanzada cuando se intenta asignar una cadena vacía a un atributo String.
 */
public class NotNullValueAllowedException extends RuntimeException {
    public NotNullValueAllowedException(String message) {
        super(message);
    }
}
