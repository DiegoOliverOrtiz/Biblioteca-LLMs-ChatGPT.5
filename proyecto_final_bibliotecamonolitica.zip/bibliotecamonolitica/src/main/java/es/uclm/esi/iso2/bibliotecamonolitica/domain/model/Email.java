package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

/** Objeto de valor para Email (validación mínima). */
public class Email {
    private String value;
    public Email(String value) {
        if (value == null || value.trim().isEmpty() || !value.contains("@")) {
            throw new IllegalArgumentException("Email inválido");
        }
        this.value = value;
    }
    public String getValue() { return value; }
    public void setValue(String value) {
        if (value == null || value.trim().isEmpty() || !value.contains("@")) {
            throw new IllegalArgumentException("Email inválido");
        }
        this.value = value;
    }
    @Override public String toString() { return value; }
}
