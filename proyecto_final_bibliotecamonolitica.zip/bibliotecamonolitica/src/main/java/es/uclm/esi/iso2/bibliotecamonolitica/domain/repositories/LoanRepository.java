package es.uclm.esi.iso2.bibliotecamonolitica.domain.repositories;

import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Loan;
import java.util.Optional;

/** Contrato de repositorio para Loan (simplificado). */
public interface LoanRepository {
    void save(Loan loan);
    Optional<Loan> findById(String id);
}
