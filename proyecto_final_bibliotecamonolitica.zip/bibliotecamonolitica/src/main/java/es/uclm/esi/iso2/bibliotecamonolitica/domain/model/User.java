package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import es.uclm.esi.iso2.bibliotecamonolitica.common.util.Validation;

/** Entidad Usuario. */
public class User {
    private String name;
    private Email email;

    public User(String name, Email email) {
        setName(name);
        setEmail(email);
    }

    public void setName(String name) {
        this.name = Validation.requireText(name, "name");
    }
    public String getName() { return name; }

    public void setEmail(Email email) {
        if (email == null) throw new IllegalArgumentException("email no puede ser null");
        this.email = email;
    }
    public Email getEmail() { return email; }
}
