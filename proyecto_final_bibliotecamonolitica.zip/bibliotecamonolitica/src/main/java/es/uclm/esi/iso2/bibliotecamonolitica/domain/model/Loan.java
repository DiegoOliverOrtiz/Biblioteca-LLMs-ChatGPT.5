package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import java.time.LocalDate;

/** Entidad Préstamo. */
public class Loan {
    private Book book;
    private User user;
    private LocalDate startDate;
    private LocalDate dueDate;
    private boolean closed;

    public Loan(Book book, User user, LocalDate startDate, LocalDate dueDate) {
        setBook(book);
        setUser(user);
        setStartDate(startDate);
        setDueDate(dueDate);
    }

    public void setBook(Book book) { if (book == null) throw new IllegalArgumentException("book null"); this.book = book; }
    public Book getBook() { return book; }

    public void setUser(User user) { if (user == null) throw new IllegalArgumentException("user null"); this.user = user; }
    public User getUser() { return user; }

    public void setStartDate(LocalDate startDate) { if (startDate == null) throw new IllegalArgumentException("startDate null"); this.startDate = startDate; }
    public LocalDate getStartDate() { return startDate; }

    public void setDueDate(LocalDate dueDate) { if (dueDate == null) throw new IllegalArgumentException("dueDate null"); this.dueDate = dueDate; }
    public LocalDate getDueDate() { return dueDate; }

    public void setClosed(boolean closed) { this.closed = closed; }
    public boolean isClosed() { return closed; }
}
