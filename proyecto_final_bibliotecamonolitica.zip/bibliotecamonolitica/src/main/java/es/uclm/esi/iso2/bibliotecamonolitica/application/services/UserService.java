package es.uclm.esi.iso2.bibliotecamonolitica.application.services;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.UserDAO;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.User;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Email;
import java.util.Optional;

/** Servicio de usuarios (vía DAO/AgentMySQL). */
public class UserService {
    private UserDAO userDAO;
    public UserService() {     public UserDAO getUserDAO() { return userDAO; }
    public void setUserDAO(UserDAO userDAO) { this.userDAO = userDAO; }
}

    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }
    public void save(User user) { userDAO.save(user); }
    public Optional<User> findByEmail(Email email) { return Optional.ofNullable(userDAO.findByEmail(email)); }
}
