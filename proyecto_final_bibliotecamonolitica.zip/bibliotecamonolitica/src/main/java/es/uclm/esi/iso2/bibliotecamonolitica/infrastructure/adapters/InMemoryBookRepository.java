package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters;

import es.uclm.esi.iso2.bibliotecamonolitica.domain.repositories.BookRepository;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Book;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.ISBN;
import java.util.*;

/** Implementación en memoria para demo. */
public class InMemoryBookRepository implements BookRepository {
    private final Map<String, Book> storage = new HashMap<>();
    public void save(Book book) { storage.put(book.getIsbn().getValue(), book); }
    public Optional<Book> findByIsbn(ISBN isbn) { return Optional.ofNullable(storage.get(isbn.getValue())); }
}
