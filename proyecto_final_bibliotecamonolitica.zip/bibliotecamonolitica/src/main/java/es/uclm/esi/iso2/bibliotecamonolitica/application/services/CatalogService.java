package es.uclm.esi.iso2.bibliotecamonolitica.application.services;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.BookDAO;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Book;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.ISBN;
import java.util.Optional;

/** Servicio de catálogo (vía DAO/AgentMySQL). */
public class CatalogService {
    private BookDAO bookDAO;
    public CatalogService() {     public BookDAO getBookDAO() { return bookDAO; }
    public void setBookDAO(BookDAO bookDAO) { this.bookDAO = bookDAO; }
}

    public CatalogService(BookDAO bookDAO) {
        this.bookDAO = bookDAO;
    }
    public Optional<Book> findByIsbn(ISBN isbn) {
        return Optional.ofNullable(bookDAO.findByIsbn(isbn));
    }
    public void save(Book book) {
        bookDAO.save(book);
    }
}
