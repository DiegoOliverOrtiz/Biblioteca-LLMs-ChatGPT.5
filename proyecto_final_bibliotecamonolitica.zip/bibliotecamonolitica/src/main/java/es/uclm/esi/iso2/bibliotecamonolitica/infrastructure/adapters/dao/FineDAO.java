package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;
import java.sql.*;
import java.math.BigDecimal;

public class FineDAO {
    public void save(String loanId, Fine fine) {
        String sql = "INSERT INTO fines (loan_id, amount, applied_on) VALUES (?, ?, ?) "
                   + "ON DUPLICATE KEY UPDATE amount=?, applied_on=?";
        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, loanId);
            ps.setBigDecimal(2, fine.getAmount().getAmount());
            ps.setDate(3, Date.valueOf(fine.getAppliedOn()));
            ps.setBigDecimal(4, fine.getAmount().getAmount());
            ps.setDate(5, Date.valueOf(fine.getAppliedOn()));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error guardando Fine", e);
        }
    }
}
