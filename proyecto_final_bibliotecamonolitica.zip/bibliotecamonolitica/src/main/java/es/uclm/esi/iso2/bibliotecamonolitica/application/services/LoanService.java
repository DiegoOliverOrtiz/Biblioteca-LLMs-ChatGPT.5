package es.uclm.esi.iso2.bibliotecamonolitica.application.services;

import es.uclm.esi.iso2.bibliotecamonolitica.domain.repositories.LoanRepository;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Loan;
import java.time.LocalDate;

/** Servicio de préstamos. */
public class LoanService {
    private LoanRepository loanRepository;
    public LoanService() {     public LoanRepository getLoanRepository() { return loanRepository; }
    public void setLoanRepository(LoanRepository loanRepository) { this.loanRepository = loanRepository; }
}

    public LoanService(LoanRepository loanRepository) {
        this.loanRepository = loanRepository;
    }
    public void renew(Loan loan, int days) {
        loan.setDueDate(loan.getDueDate().plusDays(days));
        loanRepository.save(loan);
    }
    public void close(Loan loan) {
        loan.setClosed(true);
        loanRepository.save(loan);
    }
}
