package es.uclm.esi.iso2.bibliotecamonolitica.domain.repositories;

import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.User;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Email;
import java.util.Optional;

/** Contrato de repositorio para User. */
public interface UserRepository {
    void save(User user);
    Optional<User> findByEmail(Email email);
}
