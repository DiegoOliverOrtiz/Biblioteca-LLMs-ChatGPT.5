package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import java.time.LocalDate;

/** Entidad Multa. */
public class Fine {
    private Money amount;
    private LocalDate appliedOn;

    public Fine(Money amount, LocalDate appliedOn) {
        setAmount(amount);
        setAppliedOn(appliedOn);
    }

    public void setAmount(Money amount) { if (amount == null) throw new IllegalArgumentException("amount null"); this.amount = amount; }
    public Money getAmount() { return amount; }

    public void setAppliedOn(LocalDate appliedOn) { if (appliedOn == null) throw new IllegalArgumentException("appliedOn null"); this.appliedOn = appliedOn; }
    public LocalDate getAppliedOn() { return appliedOn; }
}
