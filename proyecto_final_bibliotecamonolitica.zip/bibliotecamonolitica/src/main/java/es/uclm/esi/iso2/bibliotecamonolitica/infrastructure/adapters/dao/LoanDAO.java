package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;
import java.sql.*;
import java.time.LocalDate;

public class LoanDAO {
    public void save(String id, Loan loan) {
        String sql = "INSERT INTO loans (id, user_email, book_isbn, start_date, due_date, closed) VALUES (?, ?, ?, ?, ?, ?) "
                   + "ON DUPLICATE KEY UPDATE start_date=?, due_date=?, closed=?";
        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id);
            ps.setString(2, loan.getUser().getEmail().getValue());
            ps.setString(3, loan.getBook().getIsbn().getValue());
            ps.setDate(4, Date.valueOf(loan.getStartDate()));
            ps.setDate(5, Date.valueOf(loan.getDueDate()));
            ps.setBoolean(6, loan.isClosed());
            ps.setDate(7, Date.valueOf(loan.getStartDate()));
            ps.setDate(8, Date.valueOf(loan.getDueDate()));
            ps.setBoolean(9, loan.isClosed());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error guardando Loan", e);
        }
    }
}
