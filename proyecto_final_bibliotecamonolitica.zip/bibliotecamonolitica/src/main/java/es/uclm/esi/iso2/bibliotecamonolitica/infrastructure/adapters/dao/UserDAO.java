package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.User;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Email;

import java.sql.*;

public class UserDAO {
    public void save(User user) {
        String sql = "INSERT INTO users (email, name) VALUES (?, ?) ON DUPLICATE KEY UPDATE name=?";
        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, user.getEmail().getValue());
            ps.setString(2, user.getName());
            ps.setString(3, user.getName());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error guardando User", e);
        }
    }

    public User findByEmail(Email email) {
        String sql = "SELECT name FROM users WHERE email=?";
        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, email.getValue());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new User(rs.getString("name"), email);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Error buscando User por email", e);
        }
    }
}
