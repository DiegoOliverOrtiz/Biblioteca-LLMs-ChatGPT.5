package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import es.uclm.esi.iso2.bibliotecamonolitica.common.util.Validation;

/** Entidad Libro. */
public class Book {
    private String title;
    private String author;
    private ISBN isbn;

    /** Constructor con setters para garantizar validaciones homogéneas. */
    public Book(String title, String author, ISBN isbn) {
        setTitle(title);
        setAuthor(author);
        setIsbn(isbn);
    }

    /** Título no permite cadena vacía. */
    public void setTitle(String title) {
        this.title = Validation.requireText(title, "title");
    }
    public String getTitle() { return title; }

    /** Autor no permite cadena vacía. */
    public void setAuthor(String author) {
        this.author = Validation.requireText(author, "author");
    }
    public String getAuthor() { return author; }

    public void setIsbn(ISBN isbn) {
        if (isbn == null) throw new IllegalArgumentException("isbn no puede ser null");
        this.isbn = isbn;
    }
    public ISBN getIsbn() { return isbn; }
}
