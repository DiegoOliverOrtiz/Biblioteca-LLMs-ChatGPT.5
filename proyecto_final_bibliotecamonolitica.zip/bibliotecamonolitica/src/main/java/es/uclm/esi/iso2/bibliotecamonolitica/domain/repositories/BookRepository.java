package es.uclm.esi.iso2.bibliotecamonolitica.domain.repositories;

import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Book;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.ISBN;
import java.util.Optional;

/** Contrato de repositorio para Book. */
public interface BookRepository {
    void save(Book book);
    Optional<Book> findByIsbn(ISBN isbn);
}
