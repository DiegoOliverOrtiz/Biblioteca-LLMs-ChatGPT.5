package es.uclm.esi.iso2.bibliotecamonolitica.presentation.controllers;

import es.uclm.esi.iso2.bibliotecamonolitica.application.services.CatalogService;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Book;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.ISBN;
import java.util.Optional;

/** Controlador de libros (stub). */
public class BookController {
    private CatalogService catalogService;
    public BookController() {     public CatalogService getCatalogService() { return catalogService; }
    public void setCatalogService(CatalogService catalogService) { this.catalogService = catalogService; }
}

    public BookController(CatalogService catalogService) {
        this.catalogService = catalogService;
    }
    public Optional<Book> getBookByIsbn(String rawIsbn) {
        return catalogService.findByIsbn(new ISBN(rawIsbn));
    }
}
