package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Book;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.ISBN;

import java.sql.*;

public class BookDAO {
    public void save(Book book) {
        String sql = "INSERT INTO books (isbn, title, author) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE title=?, author=?";
        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, book.getIsbn().getValue());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthor());
            ps.setString(4, book.getTitle());
            ps.setString(5, book.getAuthor());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new IllegalStateException("Error guardando Book", e);
        }
    }

    public Book findByIsbn(ISBN isbn) {
        String sql = "SELECT title, author FROM books WHERE isbn=?";
        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, isbn.getValue());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Book(rs.getString("title"), rs.getString("author"), isbn);
                }
                return null;
            }
        } catch (SQLException e) {
            throw new IllegalStateException("Error buscando Book por ISBN", e);
        }
    }
}
