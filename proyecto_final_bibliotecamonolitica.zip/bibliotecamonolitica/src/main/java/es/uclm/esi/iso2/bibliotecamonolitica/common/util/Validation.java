package es.uclm.esi.iso2.bibliotecamonolitica.common.util;

import es.uclm.esi.iso2.bibliotecamonolitica.common.exceptions.NotNullValueAllowedException;

/** Utilidades de validación. */
public final class Validation {
    private Validation() { }

    /** 
     * Valida que un texto tenga contenido. Lanza NotNullValueAllowedException si es null o vacío.
     */
    public static String requireText(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new NotNullValueAllowedException("El campo '" + fieldName + "' no permite cadena vacía");
        }
        return value;
    }
}
