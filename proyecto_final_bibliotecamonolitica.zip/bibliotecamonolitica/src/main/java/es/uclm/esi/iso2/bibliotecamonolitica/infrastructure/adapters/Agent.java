package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters;

import java.sql.Connection;

/**
 * Agente abstracto (Singleton) para gestionar conexiones con el SGBD.
 */
public abstract class Agent {
    /** Solo para pruebas: inyecta una instancia custom del agente. */
    public static void setInstanceForTesting(Agent custom) { instance = custom; }

    protected static Agent instance;

    /** Obtiene la instancia singleton del agente. */
    public static Agent getInstance() {
        if (instance == null) {
            throw new IllegalStateException("No hay instancia de Agent configurada. Inicializa AgentMySQL primero.");
        }
        return instance;
    }

    /** Devuelve una conexión válida; la implementación gestiona el pool o DriverManager. */
    public abstract Connection getConnection();

    /** Cierra recursos del agente (si aplica). */
    public abstract void close();
}
