package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

/** Objeto de valor para ISBN (simplificado). */
public class ISBN {
    private String value;
    public ISBN(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("ISBN no puede ser vacío");
        }
        this.value = value;
    }
    public String getValue() { return value; }
    public void setValue(String value) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException("ISBN no puede ser vacío");
        }
        this.value = value;
    }
    @Override public String toString() { return value; }
}
