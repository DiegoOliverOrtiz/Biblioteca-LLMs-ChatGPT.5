package es.uclm.esi.iso2.bibliotecamonolitica;

import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.AgentMySQL;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.BookDAO;
import es.uclm.esi.iso2.bibliotecamonolitica.application.services.CatalogService;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.Book;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.ISBN;

/**
 * Punto de entrada de la aplicación.
 * Requiere que existan tablas en MySQL (ver resources/sql/schema.sql) y variables de entorno MYSQL_URL, MYSQL_USER, MYSQL_PASSWORD.
 */
public class Main {
    public static void main(String[] args) {
        AgentMySQL.initFromEnv();
        var catalog = new CatalogService(new BookDAO());
        catalog.save(new Book("El Quijote", "Miguel de Cervantes", new ISBN("9788491050297")));
        System.out.println(catalog.findByIsbn(new ISBN("9788491050297")).map(Book::getTitle).orElse("No encontrado"));
    }
}
