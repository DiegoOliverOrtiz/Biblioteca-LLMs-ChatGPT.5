package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Implementación concreta del Agent para MySQL.
 * Configura la conexión vía variables de entorno:
 * MYSQL_URL (p.ej., jdbc:mysql://localhost:3306/biblioteca?useSSL=false&serverTimezone=UTC)
 * MYSQL_USER, MYSQL_PASSWORD
 */
public class AgentMySQL extends Agent {
    private String url;
    private String user;
    private String password;

    private AgentMySQL(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
        public String getUrl() { return url; }
    public void setUrl(String url) { this.url = url; }
    public String getUser() { return user; }
    public void setUser(String user) { this.user = user; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
}


    /** Inicializa el singleton con parámetros de entorno o explícitos. */
    public static synchronized void initFromEnv() {
        String url = System.getenv().getOrDefault("MYSQL_URL", "jdbc:mysql://localhost:3306/biblioteca?useSSL=false&serverTimezone=UTC");
        String user = System.getenv().getOrDefault("MYSQL_USER", "root");
        String password = System.getenv().getOrDefault("MYSQL_PASSWORD", "");
        instance = new AgentMySQL(url, user, password);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Driver MySQL no encontrado en el classpath", e);
        }
    }

    public static synchronized void init(String url, String user, String password) {
        instance = new AgentMySQL(url, user, password);
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Driver MySQL no encontrado en el classpath", e);
        }
    }

    @Override
    public Connection getConnection() {
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            throw new IllegalStateException("No se pudo obtener conexión MySQL", e);
        }
    }

    @Override
    public void close() {
        // Con DriverManager no hay pool; nada que cerrar.
    }
}
