package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import java.math.BigDecimal;
import java.util.Objects;

/** Objeto de valor para dinero. Inmutable. */
public class Money {
    private BigDecimal amount;
    public Money(BigDecimal amount) {
        this.amount = Objects.requireNonNull(amount, "amount");
    }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) {
        this.amount = java.util.Objects.requireNonNull(amount, "amount");
    }
    public Money add(Money other) { return new Money(this.amount.add(other.amount)); }
    @Override public String toString() { return amount.toPlainString(); }
}
