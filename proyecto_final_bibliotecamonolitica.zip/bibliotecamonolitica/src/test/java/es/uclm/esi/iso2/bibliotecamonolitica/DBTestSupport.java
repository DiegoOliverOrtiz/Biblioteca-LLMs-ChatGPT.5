package es.uclm.esi.iso2.bibliotecamonolitica;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Statement;
import java.util.stream.Collectors;

/** Utilidades para inicializar esquema/datos de prueba. */
public final class DBTestSupport {
    private DBTestSupport() { }

    public static void runSqlResource(Connection c, String resourcePath) throws Exception {
        try (InputStream is = DBTestSupport.class.getResourceAsStream(resourcePath)) {
            if (is == null) throw new IllegalArgumentException("No se encontró recurso: " + resourcePath);
            String sql = new BufferedReader(new InputStreamReader(is))
                .lines().collect(Collectors.joining("\n"));
            for (String stmt : sql.split(";\n")) {
                String s = stmt.trim();
                if (s.isEmpty()) continue;
                try (Statement st = c.createStatement()) {
                    st.execute(s);
                }
            }
        }
    }
}
