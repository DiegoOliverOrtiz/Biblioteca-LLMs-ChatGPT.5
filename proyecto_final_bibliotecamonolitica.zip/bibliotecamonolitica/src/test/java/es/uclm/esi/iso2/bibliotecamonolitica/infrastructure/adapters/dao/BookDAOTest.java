package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.AgentH2;
import es.uclm.esi.iso2.bibliotecamonolitica.DBTestSupport;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;

import java.sql.Connection;

public class BookDAOTest {
    @BeforeAll
    static void setupDb() throws Exception {
        Agent.setInstanceForTesting(new AgentH2("db1"));
        try (Connection c = Agent.getInstance().getConnection()) {
            DBTestSupport.runSqlResource(c, "/sql/schema.sql");
        }
    }
    @Test
    void save_and_find() {
        BookDAO dao = new BookDAO();
        ISBN isbn = new ISBN("9789999999999");
        dao.save(new Book("T", "A", isbn));
        Book found = dao.findByIsbn(isbn);
        assertNotNull(found);
        assertEquals("T", found.getTitle());
    }
}
