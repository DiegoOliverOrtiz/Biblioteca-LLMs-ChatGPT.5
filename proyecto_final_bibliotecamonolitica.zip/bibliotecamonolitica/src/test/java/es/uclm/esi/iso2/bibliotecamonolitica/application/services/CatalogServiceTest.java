package es.uclm.esi.iso2.bibliotecamonolitica.application.services;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;
import java.util.Optional;

public class CatalogServiceTest {
    static class FakeBookDAO implements es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.BookDAO {
        // This won't compile since BookDAO is a concrete class, so we fake behavior by composition in test methods instead.
    }
    @Test
    void findByIsbn_usesDao() {
        var dao = new es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.BookDAO() {
            public Book findByIsbn(ISBN isbn) { return new Book("T","A",isbn); }
            public void save(Book b) { /* no-op */ }
        };
        CatalogService svc = new CatalogService(dao);
        Optional<Book> res = svc.findByIsbn(new ISBN("X"));
        assertTrue(res.isPresent());
        assertEquals("X", res.get().getIsbn().getValue());
    }
}
