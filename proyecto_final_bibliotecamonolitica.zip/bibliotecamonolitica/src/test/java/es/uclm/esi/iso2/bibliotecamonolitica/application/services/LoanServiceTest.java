package es.uclm.esi.iso2.bibliotecamonolitica.application.services;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.repositories.LoanRepository;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;
import java.time.LocalDate;
import java.util.Optional;

public class LoanServiceTest {
    static class FakeLoanRepo implements LoanRepository {
        Loan saved;
        @Override public void save(Loan loan) { this.saved = loan; }
        @Override public Optional<Loan> findById(String id) { return Optional.ofNullable(saved); }
    }
    @Test
    void renew_and_close_persistChanges() {
        FakeLoanRepo repo = new FakeLoanRepo();
        LoanService svc = new LoanService(repo);
        Book b = new Book("T","A", new ISBN("1"));
        User u = new User("N", new Email("a@b.com"));
        Loan l = new Loan(b,u, LocalDate.now(), LocalDate.now().plusDays(7));
        svc.renew(l, 3);
        assertEquals(10, l.getDueDate().toEpochDay() - LocalDate.now().toEpochDay());
        svc.close(l);
        assertTrue(l.isClosed());
        assertNotNull(repo.saved);
    }
}
