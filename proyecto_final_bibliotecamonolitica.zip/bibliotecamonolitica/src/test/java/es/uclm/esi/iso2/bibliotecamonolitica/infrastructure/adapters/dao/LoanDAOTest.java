package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.AgentH2;
import es.uclm.esi.iso2.bibliotecamonolitica.DBTestSupport;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class LoanDAOTest {
    @BeforeAll
    static void setupDb() throws Exception {
        Agent.setInstanceForTesting(new AgentH2("db_loans"));
        try (Connection c = Agent.getInstance().getConnection()) {
            DBTestSupport.runSqlResource(c, "/sql/schema.sql");
            // seed minimal user/book for FK
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO users(email,name) VALUES(?,?)")) {
                ps.setString(1, "x@e.com"); ps.setString(2, "X"); ps.executeUpdate();
            }
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO books(isbn,title,author) VALUES(?,?,?)")) {
                ps.setString(1, "999"); ps.setString(2, "T"); ps.setString(3, "A"); ps.executeUpdate();
            }
        }
    }

    @Test
    void save_persistsLoanRow() throws Exception {
        LoanDAO dao = new LoanDAO();
        Loan l = new Loan(new Book("T","A", new ISBN("999")), new User("X", new Email("x@e.com")),
                          LocalDate.of(2025,1,1), LocalDate.of(2025,1,10));
        String id = "L1";
        dao.save(id, l);

        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM loans WHERE id=?")) {
            ps.setString(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                assertEquals(1, rs.getInt(1));
            }
        }
    }
}
