package es.uclm.esi.iso2.bibliotecamonolitica;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;

import java.time.LocalDate;

public class SetterValidationTest {
    @Test
    void emptyStringThrows() {
        assertThrows(RuntimeException.class, () -> new Book("", "Autor", new ISBN("X")));
        assertThrows(RuntimeException.class, () -> new User("", new Email("a@b.com")));
    }

    @Test
    void settersAreUsed() {
        Book b = new Book("T", "A", new ISBN("X"));
        b.setTitle("Nuevo");
        assertEquals("Nuevo", b.getTitle());
        User u = new User("N", new Email("a@b.com"));
        u.setName("Otro");
        assertEquals("Otro", u.getName());
        Loan l = new Loan(b, new User("N", new Email("c@d.com")), LocalDate.now(), LocalDate.now().plusDays(7));
        l.setClosed(true);
        assertTrue(l.isClosed());
    }
}
