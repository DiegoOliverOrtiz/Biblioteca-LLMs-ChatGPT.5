package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.math.BigDecimal;

public class ValueObjectsTest {
    @Test
    void isbn_valid() {
        ISBN i = new ISBN("X"); assertEquals("X", i.getValue());
    }
    @Test
    void isbn_invalid() {
        assertThrows(IllegalArgumentException.class, () -> new ISBN(""));
    }
    @Test
    void email_valid() {
        Email e = new Email("a@b.com"); assertEquals("a@b.com", e.getValue());
    }
    @Test
    void email_invalid() {
        assertThrows(IllegalArgumentException.class, () -> new Email("abc"));
    }
    @Test
    void money_ops() {
        Money m1 = new Money(new BigDecimal("10.00"));
        Money m2 = new Money(new BigDecimal("2.50"));
        assertEquals("12.50", m1.add(m2).toString());
    }
}
