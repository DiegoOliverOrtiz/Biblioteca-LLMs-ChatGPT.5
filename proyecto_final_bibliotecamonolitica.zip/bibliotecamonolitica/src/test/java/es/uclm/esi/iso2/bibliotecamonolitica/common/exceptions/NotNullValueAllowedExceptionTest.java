package es.uclm.esi.iso2.bibliotecamonolitica.common.exceptions;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NotNullValueAllowedExceptionTest {
    @Test
    void messageIsPropagated() {
        NotNullValueAllowedException ex = new NotNullValueAllowedException("msg");
        assertEquals("msg", ex.getMessage());
    }
}
