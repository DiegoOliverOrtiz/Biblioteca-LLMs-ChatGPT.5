package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.AgentH2;
import es.uclm.esi.iso2.bibliotecamonolitica.DBTestSupport;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;

import java.sql.Connection;

public class UserDAOTest {
    @BeforeAll
    static void setupDb() throws Exception {
        Agent.setInstanceForTesting(new AgentH2("db2"));
        try (Connection c = Agent.getInstance().getConnection()) {
            DBTestSupport.runSqlResource(c, "/sql/schema.sql");
        }
    }
    @Test
    void save_and_find() {
        UserDAO dao = new UserDAO();
        Email email = new Email("u@e.com");
        dao.save(new User("Nombre", email));
        User found = dao.findByEmail(email);
        assertNotNull(found);
        assertEquals("Nombre", found.getName());
    }
}
