package es.uclm.esi.iso2.bibliotecamonolitica.common;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.common.util.Validation;
import es.uclm.esi.iso2.bibliotecamonolitica.common.exceptions.NotNullValueAllowedException;

public class ValidationTest {
    @Test
    void requireText_ok() {
        assertEquals("hola", Validation.requireText("hola", "f"));
    }
    @Test
    void requireText_throwsOnNullOrEmpty() {
        assertThrows(NotNullValueAllowedException.class, () -> Validation.requireText("", "f"));
        assertThrows(NotNullValueAllowedException.class, () -> Validation.requireText("   ", "f"));
        assertThrows(NotNullValueAllowedException.class, () -> Validation.requireText(null, "f"));
    }
}
