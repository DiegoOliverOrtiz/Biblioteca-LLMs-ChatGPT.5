package es.uclm.esi.iso2.bibliotecamonolitica.domain.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class EntitiesTest {
    @Test
    void book_setters() {
        Book b = new Book("T", "A", new ISBN("1"));
        b.setTitle("Nuevo");
        b.setAuthor("Otro");
        assertEquals("Nuevo", b.getTitle());
        assertEquals("Otro", b.getAuthor());
        assertThrows(IllegalArgumentException.class, () -> b.setIsbn(null));
    }
    @Test
    void user_setters() {
        User u = new User("N", new Email("a@b.com"));
        u.setName("X");
        u.setEmail(new Email("c@d.com"));
        assertEquals("X", u.getName());
        assertEquals("c@d.com", u.getEmail().getValue());
    }
    @Test
    void loan_and_fine() {
        Book b = new Book("T", "A", new ISBN("1"));
        User u = new User("N", new Email("a@b.com"));
        Loan l = new Loan(b, u, LocalDate.now(), LocalDate.now().plusDays(7));
        l.setClosed(true);
        assertTrue(l.isClosed());
        assertThrows(IllegalArgumentException.class, () -> l.setStartDate(null));
    }
}
