package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/** Agente de pruebas que usa H2 en memoria en modo MySQL. */
public class AgentH2 extends Agent {
    private final String url;
    public AgentH2(String dbName) {
        this.url = "jdbc:h2:mem:" + dbName + ";MODE=MySQL;DATABASE_TO_LOWER=TRUE;DEFAULT_NULL_ORDERING=HIGH;DB_CLOSE_DELAY=-1";
        try {
            Class.forName("org.h2.Driver");
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException(e);
        }
    }
    @Override
    public Connection getConnection() {
        try {
            return DriverManager.getConnection(url, "sa", "");
        } catch (SQLException e) {
            throw new IllegalStateException(e);
        }
    }
    @Override
    public void close() { /* no-op */ }
}
