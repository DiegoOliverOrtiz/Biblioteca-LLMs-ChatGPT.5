package es.uclm.esi.iso2.bibliotecamonolitica.application.services;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;
import java.util.Optional;

public class UserServiceTest {
    @Test
    void findByEmail_usesDao() {
        var dao = new es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.UserDAO() {
            public User findByEmail(Email email) { return new User("N", email); }
            public void save(User u) { /* no-op */ }
        };
        UserService svc = new UserService(dao);
        Optional<User> res = svc.findByEmail(new Email("a@b.com"));
        assertTrue(res.isPresent());
        assertEquals("a@b.com", res.get().getEmail().getValue());
    }
}
