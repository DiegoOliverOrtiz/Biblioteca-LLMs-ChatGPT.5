package es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.Agent;
import es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.AgentH2;
import es.uclm.esi.iso2.bibliotecamonolitica.DBTestSupport;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

public class FineDAOTest {
    @BeforeAll
    static void setupDb() throws Exception {
        Agent.setInstanceForTesting(new AgentH2("db_fines"));
        try (Connection c = Agent.getInstance().getConnection()) {
            DBTestSupport.runSqlResource(c, "/sql/schema.sql");
            // seed minimal user/book/loan
            c.createStatement().execute("INSERT INTO users(email,name) VALUES('u@e.com','U')");
            c.createStatement().execute("INSERT INTO books(isbn,title,author) VALUES('111','T','A')");
            c.createStatement().execute("INSERT INTO loans(id,user_email,book_isbn,start_date,due_date,closed) VALUES('L2','u@e.com','111','2025-01-01','2025-01-10',FALSE)");
        }
    }

    @Test
    void save_persistsFineRow() throws Exception {
        FineDAO dao = new FineDAO();
        Fine f = new Fine(new Money(new BigDecimal("5.00")), LocalDate.of(2025,1,15));
        dao.save("L2", f);

        try (Connection c = Agent.getInstance().getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM fines WHERE loan_id=?")) {
            ps.setString(1, "L2");
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                assertEquals(1, rs.getInt(1));
            }
        }
    }
}
