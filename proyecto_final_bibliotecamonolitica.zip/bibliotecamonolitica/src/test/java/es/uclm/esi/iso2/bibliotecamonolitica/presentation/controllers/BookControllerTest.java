package es.uclm.esi.iso2.bibliotecamonolitica.presentation.controllers;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Optional;
import es.uclm.esi.iso2.bibliotecamonolitica.application.services.CatalogService;
import es.uclm.esi.iso2.bibliotecamonolitica.domain.model.*;

public class BookControllerTest {
    @Test
    void getBookByIsbn_delegatesToService() {
        CatalogService svc = new CatalogService(new es.uclm.esi.iso2.bibliotecamonolitica.infrastructure.adapters.dao.BookDAO() {
            @Override public Book findByIsbn(ISBN isbn) { return new Book("T","A",isbn); }
            @Override public void save(Book b) { /* no-op */ }
        });
        BookController ctrl = new BookController(svc);
        Optional<Book> res = ctrl.getBookByIsbn("X");
        assertTrue(res.isPresent());
        assertEquals("X", res.get().getIsbn().getValue());
    }
}
